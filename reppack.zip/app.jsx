// Top-level app — wires wizard steps + tweaks

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "lang": "ja",
  "theme": "light",
  "density": "cozy",
  "subcolor": "uguisu"
}/*EDITMODE-END*/;

const STEP_KEYS = ["import", "transcribe", "review", "configure", "export"];

function App() {
  const [tw, setTw] = React.useState(() => {
    try {
      return { ...TWEAK_DEFAULTS, ...JSON.parse(localStorage.getItem("reppack.tw") || "{}") };
    } catch { return TWEAK_DEFAULTS; }
  });
  const [step, setStep] = React.useState(() => {
    const s = parseInt(localStorage.getItem("reppack.step") || "0", 10);
    return Number.isFinite(s) ? Math.min(4, Math.max(0, s)) : 0;
  });
  const [dropped, setDropped] = React.useState({
    name: "walk_with_gaudi.mp3",
    size: "18.4 MB",
    duration: "24:12",
    sr: "48 kHz · stereo",
  });
  const [sourceLang, setSourceLang] = React.useState("auto");
  const [cfg, setCfg] = React.useState({
    mode: "repeat",
    pauseKind: "preset",
    pausePreset: 1.5,
    pauseRatio: 1.2,
    speed: 1,
    repeats: 2,
  });
  const [tweaksOpen, setTweaksOpen] = React.useState(false);

  React.useEffect(() => {
    document.documentElement.dataset.theme = tw.theme;
    document.documentElement.dataset.density = tw.density;
    document.documentElement.dataset.subcolor = tw.subcolor || "uguisu";
    localStorage.setItem("reppack.tw", JSON.stringify(tw));
  }, [tw]);
  React.useEffect(() => { localStorage.setItem("reppack.step", String(step)); }, [step]);

  // edit mode wiring
  React.useEffect(() => {
    const onMsg = (e) => {
      if (!e.data || typeof e.data !== "object") return;
      if (e.data.type === "__activate_edit_mode") setTweaksOpen(true);
      if (e.data.type === "__deactivate_edit_mode") setTweaksOpen(false);
    };
    window.addEventListener("message", onMsg);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  const update = (patch) => {
    setTw(s => ({ ...s, ...patch }));
    try {
      window.parent.postMessage({ type: "__edit_mode_set_keys", edits: patch }, "*");
    } catch {}
  };

  const t = window.useI18n(tw.lang);

  const stepCmp = {
    0: <StepImport t={t} lang={tw.lang} onNext={() => setStep(1)} dropped={dropped} setDropped={setDropped} sourceLang={sourceLang} setSourceLang={setSourceLang} />,
    1: <StepTranscribe t={t} onNext={() => setStep(2)} onBack={() => setStep(0)} />,
    2: <StepReview t={t} onNext={() => setStep(3)} onBack={() => setStep(1)} />,
    3: <StepConfigure t={t} onNext={() => setStep(4)} onBack={() => setStep(2)} cfg={cfg} setCfg={setCfg} />,
    4: <StepExport t={t} onBack={() => setStep(3)} onRestart={() => setStep(0)} cfg={cfg} />,
  }[step];

  return (
    <div className="app-shell" data-screen-label={`Wizard/${STEP_KEYS[step]}`}>
      <MacWindowChrome title={`${t.appTitle} — ${dropped.name}`}>
        <WizardSidebar t={t} stepIndex={step} onStep={setStep} stepKeys={STEP_KEYS} />
        {stepCmp}
      </MacWindowChrome>

      {/* Tweaks FAB */}
      <button className="tweaks-fab" onClick={() => setTweaksOpen(v => !v)} title="Tweaks">
        <Icon name="sliders" size={18} stroke={2} />
      </button>
      <TweaksPanel open={tweaksOpen} onClose={() => setTweaksOpen(false)} state={tw} update={update} />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
