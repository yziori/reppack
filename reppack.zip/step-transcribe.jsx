// Step 2 — Analyze audio: silence detection + transcription
// Two-phase progress. Clean, non-technical UI.

const StepTranscribe = ({ t, onNext, onBack }) => {
  const TOTAL_AUDIO = 1452; // 24:12 in seconds
  const [prog, setProg] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setProg(p => Math.min(100, p + 0.9)), 80);
    return () => clearInterval(id);
  }, []);

  // Phase split: silence detection is fast (~15%), transcription is the rest.
  const phase = prog < 15 ? 0 : 1;

  const remainSec = Math.max(1, Math.round((100 - prog) * 0.8));
  const processedSec = Math.round((prog / 100) * TOTAL_AUDIO);

  const fmt = s => `${Math.floor(s/60)}:${String(s%60).padStart(2,"0")}`;

  return (
    <CanvasShell
      head={
        <div>
          <div className="eyebrow">step 02 · analyze</div>
          <h1 className="display-h" style={{ marginTop: 10 }}>
            {t.trans_h}
          </h1>
          <div className="lede" style={{ marginTop: 12, maxWidth: "60ch" }}>
            {t.trans_sub}
          </div>
        </div>
      }
      right={
        <div style={{
          fontFamily: "var(--f-serif)", fontStyle: "italic",
          color: "var(--ink-500)", textAlign: "right",
        }}>
          <div style={{ fontSize: 11, color: "var(--ink-300)", letterSpacing: "0.05em" }}>PAGE</div>
          <div style={{ fontFamily: "var(--f-serif)", fontSize: 26, fontWeight: 600, color: "var(--ink-900)" }}>02</div>
          <div style={{ fontSize: 10, color: "var(--ink-300)" }}>— of 05 —</div>
        </div>
      }
      foot={
        <>
          <button className="btn btn-ghost" onClick={onBack}>
            <Icon name="back" size={14} /> {t.back}
          </button>
          <div style={{ flex: 1 }} />
          <button className="btn btn-primary" onClick={onNext} disabled={prog < 100}>
            {prog < 100 ? `${Math.floor(prog)}%` : t.next}
            {prog >= 100 && <Icon name="next" size={14} stroke={2} />}
          </button>
        </>
      }
    >
      <div data-screen-label="02 Transcribe"
        style={{
          display: "grid", gridTemplateColumns: "1fr",
          gap: 28, maxWidth: 720, margin: "8px auto 0",
        }}>

        {/* Phase card */}
        <div style={{
          padding: 28, borderRadius: 16,
          background: "var(--paper-0)",
          border: "0.5px solid var(--paper-edge)",
          boxShadow: "var(--shadow-sm)",
        }}>
          {/* phase label row */}
          <div style={{
            display: "flex", alignItems: "center",
            gap: 10, marginBottom: 22,
          }}>
            <div style={{
              fontFamily: "var(--f-mono)", fontSize: 11,
              letterSpacing: "0.06em",
              color: "var(--ink-500)",
            }}>
              {phase === 0 ? "PHASE 1 / 2" : "PHASE 2 / 2"}
            </div>
            <div style={{
              flex: 1, height: 1, background: "var(--paper-edge)",
            }}/>
          </div>

          <div style={{
            fontFamily: "var(--f-serif)", fontSize: 22,
            fontWeight: 600, color: "var(--ink-900)",
            marginBottom: 18,
          }}>
            {phase === 0 ? t.trans_stage1 : t.trans_stage2}
          </div>

          {/* Progress bar */}
          <div style={{
            height: 8, borderRadius: 4,
            background: "var(--paper-3)",
            overflow: "hidden",
            marginBottom: 10,
          }}>
            <div style={{
              height: "100%", width: `${prog}%`,
              background: "var(--accent-500)",
              transition: "width 0.12s linear",
              borderRadius: 4,
            }} />
          </div>

          <div style={{
            display: "flex", justifyContent: "space-between",
            fontFamily: "var(--f-mono)", fontSize: 12,
            color: "var(--ink-700)",
          }}>
            <span>{Math.round(prog)}%</span>
            <span>
              {t.trans_processed} <strong style={{ color: "var(--ink-900)" }}>{fmt(processedSec)}</strong>
              {" / "}
              {fmt(TOTAL_AUDIO)}
            </span>
            <span>
              {prog < 100
                ? <>{t.trans_remaining}: <strong style={{ color: "var(--ink-900)" }}>~{remainSec}s</strong></>
                : <strong style={{ color: "var(--ok)" }}>完了</strong>}
            </span>
          </div>

          {/* Latest segment preview (only during phase 2) */}
          {phase === 1 && (
            <div style={{
              marginTop: 28, paddingTop: 22,
              borderTop: "0.5px dashed var(--paper-edge)",
            }}>
              <div style={{
                fontSize: 10.5, fontWeight: 600,
                letterSpacing: "0.08em", textTransform: "uppercase",
                color: "var(--ink-500)", marginBottom: 10,
              }}>
                直近のセグメント
              </div>
              <TranscriptStream prog={prog} />
            </div>
          )}
        </div>

        {/* Subtle meta — segments detected only */}
        <div style={{
          display: "flex", justifyContent: "center",
          padding: "0 4px",
        }}>
          <Stat
            label="検出済みセグメント"
            value={phase === 0 ? "—" : String(Math.max(0, Math.floor((prog - 15) / 85 * 38)))}
          />
        </div>
      </div>
    </CanvasShell>
  );
};

const Stat = ({ label, value }) => (
  <div style={{ textAlign: "center" }}>
    <div style={{
      fontFamily: "var(--f-serif)", fontSize: 20, fontWeight: 600,
      color: "var(--ink-900)",
    }}>{value}</div>
    <div style={{
      fontSize: 11, color: "var(--ink-500)", marginTop: 2,
    }}>{label}</div>
  </div>
);

const STREAM_LINES = [
  "The Sagrada Família,",
  "a basilica in Barcelona,",
  "is the most famous work of architect Antoni Gaudí.",
  "But it was not finished in his lifetime.",
  "When Gaudí died in 1926,",
  "he had worked on the building for more than 40 years.",
];

const TranscriptStream = ({ prog }) => {
  const shown = Math.floor(((prog - 15) / 85) * (STREAM_LINES.length + 0.2));
  return (
    <div style={{
      fontFamily: "var(--f-serif)", fontSize: 15,
      lineHeight: 1.7, color: "var(--ink-700)",
      minHeight: 44,
    }}>
      {STREAM_LINES.slice(0, shown).map((l, i) => (
        <span key={i} style={{
          marginRight: 4,
          color: i === shown - 1 ? "var(--ink-900)" : "var(--ink-700)",
        }}>{l} </span>
      ))}
      {prog < 100 && shown > 0 && <span className="blink" style={{
        display: "inline-block", width: 7, height: 15,
        verticalAlign: "middle",
        background: "var(--accent-500)",
        marginLeft: 2,
      }} />}
      <style>{`@keyframes blink { 50% { opacity: 0 } } .blink { animation: blink 1s steps(2) infinite; }`}</style>
    </div>
  );
};

Object.assign(window, { StepTranscribe });
