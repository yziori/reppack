// Tweaks panel — persisted defaults

const SUBCOLORS = [
  { key: "uguisu",  label: "鶯",   sub: "うぐいす",    swatch: "oklch(0.42 0.06 135)"  },
  { key: "cha",     label: "茶",   sub: "ちゃ",        swatch: "oklch(0.40 0.07 55)"   },
  { key: "sumi",    label: "墨",   sub: "すみ",        swatch: "oklch(0.28 0.012 60)"  },
  { key: "ashi",    label: "蘆",   sub: "けんぽう",    swatch: "oklch(0.48 0.09 90)"   },
  { key: "hisui",   label: "翡",   sub: "ひすい",      swatch: "oklch(0.52 0.12 165)"  },
  { key: "kon",     label: "紺",   sub: "こん",        swatch: "oklch(0.32 0.10 255)"  },
  { key: "hanairo", label: "花色", sub: "はないろ",    swatch: "oklch(0.44 0.11 235)"  },
];

const TweaksPanel = ({ open, onClose, state, update }) => {
  if (!open) return null;
  const t = window.useI18n(state.lang);
  return (
    <div className="tweaks-panel">
      <div style={{ display: "flex", alignItems: "center" }}>
        <div className="tweaks-h" style={{ flex: 1 }}>{t.tweaks}</div>
        <button className="btn btn-icon btn-ghost" onClick={onClose} style={{ width: 24, height: 24 }}>
          <Icon name="x" size={13} />
        </button>
      </div>

      <div className="tweaks-row">
        <label>{t.tw_lang}</label>
        <div className="segmented" style={{ fontSize: 11 }}>
          <button className={state.lang === "ja" ? "on" : ""} onClick={() => update({ lang: "ja" })}>日本語</button>
          <button className={state.lang === "en" ? "on" : ""} onClick={() => update({ lang: "en" })}>EN</button>
        </div>
      </div>

      <div className="tweaks-row">
        <label>{t.tw_theme}</label>
        <div className="segmented" style={{ fontSize: 11 }}>
          <button className={state.theme === "light" ? "on" : ""} onClick={() => update({ theme: "light" })}>
            <Icon name="sun" size={11} /> {t.tw_theme_light}
          </button>
          <button className={state.theme === "dark" ? "on" : ""} onClick={() => update({ theme: "dark" })}>
            <Icon name="moon" size={11} /> {t.tw_theme_dark}
          </button>
        </div>
      </div>

      <div className="tweaks-row">
        <label>{t.tw_density}</label>
        <div className="segmented" style={{ fontSize: 11 }}>
          <button className={state.density === "cozy" ? "on" : ""} onClick={() => update({ density: "cozy" })}>{t.tw_density_cozy}</button>
          <button className={state.density === "compact" ? "on" : ""} onClick={() => update({ density: "compact" })}>{t.tw_density_compact}</button>
        </div>
      </div>

      <div className="tweaks-row" style={{ flexDirection: "column", alignItems: "stretch", gap: 10 }}>
        <label style={{ alignSelf: "flex-start" }}>
          {state.lang === "ja" ? "サブカラー（栞）" : "Accent (subcolor)"}
        </label>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(2, 1fr)",
          gap: 4,
        }}>
          {SUBCOLORS.map(c => {
            const active = (state.subcolor || "uguisu") === c.key;
            return (
              <button
                key={c.key}
                onClick={() => update({ subcolor: c.key })}
                style={{
                  display: "flex", alignItems: "center", gap: 8,
                  padding: "7px 9px",
                  border: active ? "1px solid var(--ink-indigo)" : "0.5px solid var(--paper-edge)",
                  background: active ? "var(--ink-indigo-wash)" : "var(--paper-0)",
                  borderRadius: 8, cursor: "pointer",
                  textAlign: "left",
                  transition: "all 0.12s",
                  fontFamily: "var(--f-sans)",
                }}
              >
                <div style={{
                  width: 14, height: 14, borderRadius: 3,
                  background: c.swatch,
                  border: "0.5px solid oklch(0 0 0 / 0.12)",
                  flexShrink: 0,
                }}/>
                <div style={{ minWidth: 0, lineHeight: 1.1 }}>
                  <div style={{
                    fontSize: 12,
                    fontWeight: active ? 600 : 500,
                    color: active ? "var(--ink-indigo)" : "var(--ink-900)",
                  }}>{c.label}</div>
                  <div style={{ fontSize: 9, color: "var(--ink-500)", marginTop: 1 }}>
                    {c.sub}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { TweaksPanel, SUBCOLORS });
