// Step 3 — Review segments (editorial redesign)
// Two views: "paragraph" (slash-editable prose) and "segments" (row list).
// Plus a rule editor panel, bulk actions bar, and keyboard hints.

const SEGMENTS_DATA = [
  { id: 1, start: "00:00.0", end: "00:04.2", dur: 4.2, en: "The Sagrada Família, a basilica in Barcelona,",                                     ja: "バルセロナにある大聖堂、サグラダ・ファミリアは",                 conf: 0.98 },
  { id: 2, start: "00:04.2", end: "00:09.1", dur: 4.9, en: "is the most famous work of architect Antoni Gaudí.",                             ja: "建築家アントニ・ガウディの最も有名な作品です。",                 conf: 0.96 },
  { id: 3, start: "00:09.1", end: "00:13.5", dur: 4.4, en: "But it was not finished in his lifetime.",                                       ja: "しかし、彼の生前には完成しませんでした。",                       conf: 0.99 },
  { id: 4, start: "00:13.5", end: "00:17.8", dur: 4.3, en: "When Gaudí died in 1926,",                                                       ja: "1926年にガウディが亡くなったとき、",                              conf: 0.93 },
  { id: 5, start: "00:17.8", end: "00:23.4", dur: 5.6, en: "he had worked on the building for more than 40 years.",                          ja: "彼は40年以上その建物に取り組んでいました。",                     conf: 0.97 },
  { id: 6, start: "00:23.4", end: "00:29.0", dur: 5.6, en: "However, the construction may finally be completed in around 10 years,",         ja: "しかし、建設はあと10年ほどでついに完成する見込みです。",         conf: 0.83 },
  { id: 7, start: "00:29.0", end: "00:33.2", dur: 4.2, en: "said Esteve Camps, the chairman of the project.",                                ja: "とプロジェクトの議長エステベ・キャンプス氏は語りました。",       conf: 0.95 },
  { id: 8, start: "00:33.2", end: "00:37.5", dur: 4.3, en: "The completed basilica will have 18 towers.",                                    ja: "完成した大聖堂には18本の塔が立ちます。",                         conf: 0.99 },
];

const StepReview = ({ t, onNext, onBack }) => {
  const [view, setView] = React.useState("paragraph"); // paragraph | segments
  const [selected, setSelected] = React.useState(3);
  const [playing, setPlaying] = React.useState(null);
  const showTranslation = false;

  return (
    <CanvasShell
      head={
        <div>
          <div className="eyebrow">step 03 · review</div>
          <h1 className="display-h" style={{ marginTop: 10 }}>
            {t.review_h}
          </h1>
          <div className="lede" style={{ marginTop: 12, maxWidth: "56ch" }}>
            {t.review_sub}
          </div>
        </div>
      }
      right={
        <div style={{
          fontFamily: "var(--f-serif)", fontStyle: "italic",
          color: "var(--ink-500)", textAlign: "right",
        }}>
          <div style={{ fontSize: 11, color: "var(--ink-300)", letterSpacing: "0.05em" }}>PAGE</div>
          <div style={{ fontFamily: "var(--f-serif)", fontSize: 26, fontWeight: 600, color: "var(--ink-900)" }}>03</div>
          <div style={{ fontSize: 10, color: "var(--ink-300)" }}>— of 05 —</div>
        </div>
      }
      foot={
        <>
          <button className="btn btn-ghost" onClick={onBack}>
            <Icon name="back" size={14} /> {t.back}
          </button>
          <span className="kbd" style={{ marginLeft: 4 }}>S</span>
          <span style={{ fontSize: 11, color: "var(--ink-500)" }}>分割</span>
          <span className="kbd">M</span>
          <span style={{ fontSize: 11, color: "var(--ink-500)" }}>結合</span>
          <span className="kbd">⌫</span>
          <span style={{ fontSize: 11, color: "var(--ink-500)" }}>削除</span>
          <div style={{ flex: 1 }} />
          <button className="btn btn-primary" onClick={onNext}>
            {t.next} <Icon name="next" size={13} stroke={2} />
          </button>
        </>
      }
    >
      <div data-screen-label="03 Review" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {/* Top toolbar */}
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          padding: "4px 0",
        }}>
          <div className="segmented">
            <button className={view === "paragraph" ? "on" : ""} onClick={() => setView("paragraph")}>
              <Icon name="paragraph" size={12} /> 原稿ビュー
            </button>
            <button className={view === "segments" ? "on" : ""} onClick={() => setView("segments")}>
              <Icon name="layers" size={12} /> セグメント一覧
            </button>
          </div>

          <div style={{
            height: 20, width: 1, background: "var(--paper-edge)", margin: "0 4px",
          }} />

          <div style={{ flex: 1 }} />

          <div className="chip indigo">
            <Icon name="layers" size={11} /> {t.review_count(SEGMENTS_DATA.length)}
          </div>
        </div>

        {/* Mini timeline */}
        <TimelineBar segments={SEGMENTS_DATA} selected={selected} onSelect={setSelected} />

        {/* Main body */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "1fr",
          gap: 18,
          alignItems: "flex-start",
        }}>
          <div>
            {view === "paragraph" ? (
              <ParagraphView segments={SEGMENTS_DATA} selected={selected} onSelect={setSelected} showTranslation={showTranslation} />
            ) : (
              <div style={{
                background: "var(--paper-0)",
                border: "0.5px solid var(--paper-edge)",
                borderRadius: 14,
                overflow: "hidden",
              }}>
                {SEGMENTS_DATA.map((s, i) => (
                  <SegmentRow
                    key={s.id}
                    seg={s}
                    idx={i}
                    isSelected={selected === s.id}
                    isPlaying={playing === s.id}
                    showTranslation={showTranslation}
                    onSelect={() => setSelected(s.id)}
                    onPlay={() => setPlaying(playing === s.id ? null : s.id)}
                    t={t}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Selected segment mini-inspector */}
        {view === "paragraph" && (
          <SelectedBar
            seg={SEGMENTS_DATA.find(s => s.id === selected)}
            onPlay={() => setPlaying(playing === selected ? null : selected)}
            playing={playing === selected}
            t={t}
          />
        )}
      </div>
    </CanvasShell>
  );
};

/* ─── Paragraph / slash-editable view ──────────────── */

const ParagraphView = ({ segments, selected, onSelect, showTranslation }) => {
  return (
    <div style={{
      background: "var(--paper-0)",
      border: "0.5px solid var(--paper-edge)",
      borderRadius: 14,
      padding: "28px 32px 32px",
      position: "relative",
      minHeight: 340,
    }}>
      {/* decorative rule */}
      <div className="rule-ornament" style={{ marginBottom: 18 }}>
        <span style={{ fontStyle: "italic" }}>¶ transcript</span>
      </div>

      <p style={{
        fontFamily: "var(--f-serif)",
        fontSize: 19,
        lineHeight: 1.9,
        color: "var(--ink-900)",
        margin: 0,
        textWrap: "pretty",
      }}>
        {segments.map((s, i) => (
          <React.Fragment key={s.id}>
            <span
              onClick={() => onSelect(s.id)}
              style={{
                cursor: "pointer",
                padding: "2px 1px",
                borderRadius: 3,
                background: selected === s.id
                  ? "var(--marker-yellow)"
                  : "transparent",
                borderBottom: selected === s.id
                  ? "1.5px solid var(--marker-yellow-line)"
                  : "none",
                position: "relative",
                transition: "background 0.12s",
              }}
              title={`#${s.id} · ${s.start}–${s.end}`}
            >
              {s.en}
            </span>
            {i < segments.length - 1 && (
              <span
                className="slash-mark"
                title="クリックで結合"
                style={{ fontSize: "1em" }}
              > / </span>
            )}
          </React.Fragment>
        ))}
        {" "}
        <span className="slash-mark phantom" title="ここで分割">/</span>
      </p>

      {/* translation paragraph */}
      {showTranslation && (
        <p style={{
          fontFamily: "var(--f-sans)",
          fontSize: 13.5,
          lineHeight: 1.85,
          color: "var(--ink-500)",
          marginTop: 24,
          marginBottom: 0,
          paddingTop: 18,
          borderTop: "0.5px dashed var(--paper-edge)",
          textWrap: "pretty",
        }}>
          {segments.map((s, i) => (
            <React.Fragment key={s.id}>
              <span style={{
                background: selected === s.id
                  ? "oklch(from var(--accent-500) l c h / 0.08)"
                  : "transparent",
                padding: "1px 2px",
                borderRadius: 3,
              }}>{s.ja}</span>
              {i < segments.length - 1 && <span style={{ color: "var(--ink-300)" }}> / </span>}
            </React.Fragment>
          ))}
        </p>
      )}

      {/* legend */}
      <div style={{
        marginTop: 24,
        paddingTop: 16,
        borderTop: "0.5px solid var(--paper-edge)",
        display: "flex", gap: 18,
        fontFamily: "var(--f-mono)", fontSize: 10.5,
        color: "var(--ink-500)",
      }}>
        <span>
          <span className="slash-mark">/</span>
          クリックで結合
        </span>
        <span>
          <span className="slash-mark phantom">/</span>
          文中でクリックして分割
        </span>
      </div>
    </div>
  );
};

/* ─── Segment row (list view) ─────────────────────── */

const SegmentRow = ({ seg, idx, isSelected, isPlaying, showTranslation, onSelect, onPlay, t }) => (
  <div
    onClick={onSelect}
    style={{
      display: "grid",
      gridTemplateColumns: "44px 82px 1fr auto",
      alignItems: "flex-start",
      gap: 14,
      padding: "16px 18px",
      borderTop: idx === 0 ? "none" : "0.5px solid var(--paper-edge)",
      background: isSelected ? "oklch(from var(--accent-500) l c h / 0.06)" : "transparent",
      borderLeft: isSelected ? "3px solid var(--accent-500)" : "3px solid transparent",
      cursor: "pointer",
      position: "relative",
      transition: "background 0.12s",
    }}
  >
    <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-500)", paddingTop: 4 }}>
      #{String(seg.id).padStart(2, "0")}
    </div>

    <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-700)", paddingTop: 4, lineHeight: 1.5 }}>
      <div>{seg.start}</div>
      <div style={{ color: "var(--ink-300)" }}>{seg.end}</div>
      <div style={{ color: "var(--accent-500)", marginTop: 4 }}>{seg.dur.toFixed(1)}s</div>
    </div>

    <div>
      <div style={{ fontFamily: "var(--f-serif)", fontSize: 16, color: "var(--ink-900)", lineHeight: 1.55 }}>
        {seg.en}
      </div>
      {showTranslation && (
        <div style={{
          marginTop: 6, fontFamily: "var(--f-sans)", fontSize: 12.5,
          color: "var(--ink-500)", lineHeight: 1.5,
          paddingLeft: 10,
          borderLeft: "2px solid var(--ink-indigo-wash)",
        }}>
          {seg.ja}
        </div>
      )}
      <div style={{
        marginTop: 8, display: "flex", gap: 6, alignItems: "center",
        fontSize: 11, color: "var(--ink-300)", fontFamily: "var(--f-mono)",
      }}>
        <span>{seg.dur.toFixed(1)}s</span>
      </div>
    </div>

    <div style={{ display: "flex", gap: 4, opacity: isSelected ? 1 : 0.4 }}>
      <button className="btn btn-icon tt" data-tip="再生" onClick={(e) => { e.stopPropagation(); onPlay(); }}
        style={{ height: 30, width: 30 }}>
        <Icon name={isPlaying ? "pause" : "play"} size={13} />
      </button>
      <button className="btn btn-icon tt" data-tip="前と結合" style={{ height: 30, width: 30 }}>
        <Icon name="merge" size={13} />
      </button>
      <button className="btn btn-icon tt" data-tip="ここで分割" style={{ height: 30, width: 30 }}>
        <Icon name="split" size={13} />
      </button>
      <button className="btn btn-icon tt" data-tip="文字起こしを編集" style={{ height: 30, width: 30 }}>
        <Icon name="pencil" size={13} />
      </button>
      <button className="btn btn-icon tt" data-tip="削除" style={{ height: 30, width: 30 }}>
        <Icon name="trash" size={13} />
      </button>
    </div>
  </div>
);

const ConfidenceDot = ({ conf }) => null;

/* ─── Timeline bar ─────────────────────────────── */

const TimelineBar = ({ segments, selected, onSelect }) => {
  const total = segments.reduce((a, s) => a + s.dur, 0);
  return (
    <div style={{
      padding: "14px 16px",
      background: "var(--paper-0)",
      border: "0.5px solid var(--paper-edge)",
      borderRadius: 14,
    }}>
      <div style={{
        display: "flex", justifyContent: "space-between",
        marginBottom: 10, alignItems: "center",
      }}>
        <span className="eyebrow" style={{ fontSize: 10 }}>timeline</span>
        <span style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-500)" }}>
          00:00 — 00:37.5 · {total.toFixed(1)}s
        </span>
      </div>
      <div style={{ height: 32, display: "flex", gap: 2, borderRadius: 6, overflow: "hidden" }}>
        {segments.map((s) => {
          const w = (s.dur / total) * 100;
          return (
            <button key={s.id}
              onClick={() => onSelect(s.id)}
              className="tt"
              data-tip={`#${s.id} · ${s.dur.toFixed(1)}s`}
              style={{
                flex: `0 0 ${w}%`,
                background: selected === s.id
                  ? "var(--accent-500)"
                  : "var(--ink-indigo)",
                border: "none", cursor: "pointer",
                opacity: selected === s.id ? 1 : 0.55,
                fontFamily: "var(--f-mono)", fontSize: 10,
                color: "oklch(0.98 0.01 80)",
                paddingLeft: 6, textAlign: "left",
                transition: "opacity 0.15s",
              }}>
              {w > 12 && `#${s.id}`}
            </button>
          );
        })}
      </div>
    </div>
  );
};

/* ─── Selected segment inspector bar ────────────── */

const SelectedBar = ({ seg, onPlay, playing, t }) => {
  if (!seg) return null;
  return (
    <div className="step-enter" style={{
      display: "flex", alignItems: "center", gap: 14,
      padding: "12px 16px",
      background: "var(--paper-2)",
      border: "0.5px solid var(--paper-edge)",
      borderRadius: 12,
    }}>
      <button className="btn btn-icon" onClick={onPlay}
        style={{ width: 36, height: 36, borderRadius: "50%",
          background: "var(--accent-500)",
          color: "oklch(0.98 0.01 80)", borderColor: "var(--accent-600)" }}>
        <Icon name={playing ? "pause" : "play"} size={13} />
      </button>
      <div style={{ fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-700)" }}>
        <div style={{ color: "var(--accent-500)", fontWeight: 600 }}>#{String(seg.id).padStart(2, "0")}</div>
        <div>{seg.start} → {seg.end}  ·  {seg.dur.toFixed(1)}s</div>
      </div>
      <div style={{
        flex: 1,
        fontFamily: "var(--f-serif)", fontSize: 14,
        color: "var(--ink-700)", fontStyle: "italic",
        overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
      }}>
        “{seg.en}”
      </div>
      <div style={{ display: "flex", gap: 4 }}>
        <button className="btn btn-icon tt" data-tip="前と結合" style={{ height: 30, width: 30 }}><Icon name="merge" size={12}/></button>
        <button className="btn btn-icon tt" data-tip="ここで分割" style={{ height: 30, width: 30 }}><Icon name="split" size={12}/></button>
        <button className="btn btn-icon tt" data-tip="編集" style={{ height: 30, width: 30 }}><Icon name="pencil" size={12}/></button>
        <button className="btn btn-icon tt" data-tip="削除" style={{ height: 30, width: 30 }}><Icon name="trash" size={12}/></button>
      </div>
    </div>
  );
};

/* ─── Rule editor panel ──────────────────────── */

const RulesPanel = ({ rules, setRules, onClose }) => {
  const set = (k, v) => setRules({ ...rules, [k]: v });
  return (
    <div className="step-enter" style={{
      background: "var(--paper-0)",
      border: "0.5px solid var(--paper-edge)",
      borderRadius: 14,
      padding: 18,
      position: "sticky",
      top: 0,
    }}>
      <div style={{
        display: "flex", alignItems: "center", marginBottom: 14,
      }}>
        <div style={{
          fontFamily: "var(--f-serif)", fontSize: 16, fontWeight: 600,
          flex: 1, color: "var(--ink-900)",
        }}>
          分割ルール
        </div>
        <button className="btn btn-icon btn-ghost" onClick={onClose}
          style={{ width: 24, height: 24 }}>
          <Icon name="x" size={12} />
        </button>
      </div>

      <div style={{
        fontFamily: "var(--f-serif)", fontStyle: "italic",
        fontSize: 12, color: "var(--ink-500)",
        marginBottom: 18, lineHeight: 1.55,
      }}>
        変更すると AI が境界を再計算します。編集済みのセグメントはそのままです。
      </div>

      <RuleRow label="最短セグメント" value={`${rules.minDur.toFixed(1)} s`}>
        <MiniSlider value={rules.minDur} min={0.5} max={4} step={0.1} onChange={v => set("minDur", v)} />
      </RuleRow>
      <RuleRow label="最長セグメント" value={`${rules.maxDur.toFixed(1)} s`}>
        <MiniSlider value={rules.maxDur} min={3} max={15} step={0.5} onChange={v => set("maxDur", v)} />
      </RuleRow>
      <RuleRow label="無音の判定" value={`${rules.silence.toFixed(2)} s`}>
        <MiniSlider value={rules.silence} min={0.1} max={1.2} step={0.05} onChange={v => set("silence", v)} />
      </RuleRow>

      <ToggleRow label="句読点で必ず区切る" value={rules.breakOnPunct} onChange={v => set("breakOnPunct", v)} />
      <ToggleRow label="短すぎるセグメントを結合" value={rules.mergeShort} onChange={v => set("mergeShort", v)} />

      <button className="btn btn-primary" style={{ width: "100%", marginTop: 14 }}>
        <Icon name="sparkle" size={13} /> 再解析を実行
      </button>
      <button className="btn btn-ghost" style={{ width: "100%", marginTop: 6, fontSize: 11 }}>
        デフォルトに戻す
      </button>
    </div>
  );
};

const RuleRow = ({ label, value, children }) => (
  <div style={{
    padding: "10px 0",
    borderTop: "0.5px solid var(--paper-edge)",
  }}>
    <div style={{
      display: "flex", justifyContent: "space-between", alignItems: "baseline",
      marginBottom: 8,
    }}>
      <span style={{ fontSize: 12, color: "var(--ink-700)", fontWeight: 500 }}>{label}</span>
      <span style={{ fontFamily: "var(--f-mono)", fontSize: 11.5, color: "var(--accent-500)", fontWeight: 600 }}>{value}</span>
    </div>
    {children}
  </div>
);

const MiniSlider = ({ value, min, max, step, onChange }) => {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div style={{ position: "relative", height: 18 }}>
      <div style={{ position: "absolute", left: 0, right: 0, top: 8, height: 2, background: "var(--paper-3)", borderRadius: 1 }}/>
      <div style={{ position: "absolute", left: 0, top: 8, height: 2, width: `${pct}%`, background: "var(--accent-500)", borderRadius: 1 }}/>
      <div style={{
        position: "absolute", left: `calc(${pct}% - 6px)`, top: 3,
        width: 12, height: 12, borderRadius: "50%",
        background: "var(--accent-500)",
        boxShadow: "0 0 0 2px oklch(0.98 0.01 80)",
      }}/>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={e => onChange(parseFloat(e.target.value))}
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0, cursor: "pointer" }}/>
    </div>
  );
};

const ToggleRow = ({ label, value, onChange }) => (
  <div onClick={() => onChange(!value)} style={{
    display: "flex", alignItems: "center", gap: 10,
    padding: "10px 0", cursor: "pointer",
    borderTop: "0.5px solid var(--paper-edge)",
  }}>
    <span style={{ flex: 1, fontSize: 12, color: "var(--ink-700)", fontWeight: 500 }}>{label}</span>
    <div style={{
      width: 30, height: 18, borderRadius: 9,
      background: value ? "var(--accent-500)" : "var(--paper-3)",
      position: "relative", transition: "background 0.15s",
      border: "0.5px solid " + (value ? "var(--accent-600)" : "var(--paper-edge)"),
    }}>
      <div style={{
        position: "absolute",
        top: 1.5, left: value ? 13 : 1.5,
        width: 13, height: 13, borderRadius: "50%",
        background: "oklch(0.98 0.01 80)",
        boxShadow: "0 1px 2px oklch(0 0 0 / 0.2)",
        transition: "left 0.15s",
      }}/>
    </div>
  </div>
);

Object.assign(window, { StepReview });
