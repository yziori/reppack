// Step 5 — Export / preview

const StepExport = ({ t, onBack, onRestart, cfg }) => {
  const [exportState, setExportState] = React.useState("idle"); // idle | exporting | done | failed
  const [prog, setProg] = React.useState(0);

  const go = () => {
    setExportState("exporting");
    setProg(0);
    const id = setInterval(() => {
      setProg(p => {
        if (p >= 100) {
          clearInterval(id);
          setExportState("done");
          return 100;
        }
        return p + 4;
      });
    }, 100);
  };

  return (
    <CanvasShell
      head={
        <div>
          <div className="eyebrow">step 05 · export</div>
          <h1 className="display-h" style={{ marginTop: 10 }}>
            <em>パッケージ</em>を<br/>書き出します。
          </h1>
          <div className="lede" style={{ marginTop: 12, maxWidth: "56ch" }}>
            左でプレビューを聴いて、右で保存先と付録を決めてください。
          </div>
        </div>
      }
      right={
        <div style={{
          fontFamily: "var(--f-serif)", fontStyle: "italic",
          color: "var(--ink-500)", textAlign: "right",
        }}>
          <div style={{ fontSize: 11, color: "var(--ink-300)", letterSpacing: "0.05em" }}>PAGE</div>
          <div style={{ fontFamily: "var(--f-serif)", fontSize: 26, fontWeight: 600, color: "var(--ink-900)" }}>05</div>
          <div style={{ fontSize: 10, color: "var(--ink-300)" }}>— of 05 —</div>
        </div>
      }
      foot={
        <>
          <button className="btn btn-ghost" onClick={onBack}>
            <Icon name="back" size={14} /> {t.back}
          </button>
          <div style={{ flex: 1 }} />
          {exportState === "done" ? (
            <>
              <button className="btn" onClick={onRestart}>
                <Icon name="sparkle" size={14} /> 新しいパッケージ
              </button>
              <button className="btn btn-primary">
                <Icon name="folder" size={14} /> {t.open_folder}
              </button>
            </>
          ) : (
            <button
              className="btn btn-primary"
              onClick={go}
              disabled={exportState === "exporting"}
              style={{ minWidth: 180 }}
            >
              {exportState === "exporting"
                ? <>書き出し中… {Math.floor(prog)}%</>
                : <><Icon name="download" size={14} /> {t.export_go}</>}
            </button>
          )}
        </>
      }
    >
      <div data-screen-label="05 Export" style={{
        display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 24,
      }}>
        {/* Preview player */}
        <PreviewPlayer t={t} cfg={cfg} />

        {/* Export options */}
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="card">
            <div className="field-label" style={{ marginBottom: 10 }}>{t.export_format}</div>
            <div className="segmented" style={{ width: "100%" }}>
              {["MP3","M4A","WAV"].map((f, i) => (
                <button key={f} className={i === 0 ? "on" : ""} style={{ flex: 1 }}>{f}</button>
              ))}
            </div>
            <div style={{
              marginTop: 10, display: "flex", gap: 8,
            }}>
              <select className="select" style={{ flex: 1 }} defaultValue="192">
                <option value="128">128 kbps</option>
                <option value="192">192 kbps</option>
                <option value="256">256 kbps</option>
                <option value="320">320 kbps</option>
              </select>
            </div>
          </div>

          <div className="card">
            <div className="field-label" style={{ marginBottom: 10 }}>{t.export_where}</div>
            <div className="btn" style={{
              width: "100%", justifyContent: "flex-start",
              fontFamily: "var(--f-mono)", fontSize: 12,
            }}>
              <Icon name="folder" size={14} />
              ~/Documents/RepPack/walk_with_gaudi/
            </div>
          </div>

          {/* State banner */}
          {exportState === "done" && (
            <div style={{
              padding: 14, borderRadius: 12,
              background: "oklch(from var(--ok) l c h / 0.1)",
              border: "0.5px solid oklch(from var(--ok) l c h / 0.3)",
              color: "var(--ok)",
              display: "flex", alignItems: "center", gap: 10,
            }}>
              <div style={{
                width: 28, height: 28, borderRadius: "50%",
                background: "var(--ok)",
                color: "oklch(0.98 0.01 80)",
                display: "grid", placeItems: "center",
              }}>
                <Icon name="check" size={14} stroke={3} />
              </div>
              <div>
                <div style={{ fontWeight: 600, color: "var(--ink-900)" }}>{t.export_ok}</div>
                <div style={{ fontSize: 11, color: "var(--ink-500)", fontFamily: "var(--f-mono)" }}>
                  walk_with_gaudi.pack.mp3 · 3.4 MB
                </div>
              </div>
            </div>
          )}

          {exportState === "exporting" && (
            <div style={{
              padding: 14, borderRadius: 12,
              background: "var(--paper-2)",
              border: "0.5px solid var(--paper-edge)",
            }}>
              <div style={{ fontSize: 12, color: "var(--ink-700)", marginBottom: 8 }}>
                セグメントをミックスダウン中…
              </div>
              <div style={{ height: 6, background: "var(--paper-3)", borderRadius: 3, overflow: "hidden" }}>
                <div style={{
                  height: "100%", width: `${prog}%`,
                  background: "var(--accent-500)",
                  transition: "width 0.1s",
                }}/>
              </div>
            </div>
          )}
        </div>
      </div>
    </CanvasShell>
  );
};

const CheckRow = ({ label, defaultOn = false }) => {
  const [on, setOn] = React.useState(defaultOn);
  return (
    <div onClick={() => setOn(!on)} style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: "8px 4px", cursor: "pointer",
      borderBottom: "0.5px solid var(--paper-edge)",
    }}>
      <div style={{
        width: 18, height: 18, borderRadius: 5,
        background: on ? "var(--accent-500)" : "var(--paper-0)",
        border: "1px solid " + (on ? "var(--accent-500)" : "var(--paper-edge)"),
        display: "grid", placeItems: "center",
        color: "oklch(0.98 0.01 80)",
      }}>
        {on && <Icon name="check" size={12} stroke={3} />}
      </div>
      <span style={{ fontSize: 13, color: "var(--ink-900)", flex: 1 }}>{label}</span>
    </div>
  );
};

const PreviewPlayer = ({ t, cfg }) => {
  const [playing, setPlaying] = React.useState(false);
  const [pos, setPos] = React.useState(0.18);

  React.useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => setPos(p => p >= 1 ? 0 : p + 0.006), 100);
    return () => clearInterval(id);
  }, [playing]);

  // Build a stylized timeline
  return (
    <div className="card" style={{
      padding: 0, overflow: "hidden",
      background: "var(--paper-0)",
    }}>
      <div style={{
        padding: "14px 18px",
        borderBottom: "0.5px solid var(--paper-edge)",
        display: "flex", alignItems: "center", gap: 10,
      }}>
        <span className="chip accent">
          <Icon name="headphones" size={11} /> Preview
        </span>
        <span style={{
          fontSize: 11, fontFamily: "var(--f-mono)",
          color: "var(--ink-500)",
        }}>
          {cfg.mode} · ×{cfg.speed} · pause {cfg.pauseKind === "preset" ? "×" + cfg.pausePreset : "ratio " + cfg.pauseRatio}
        </span>
      </div>

      {/* Excerpt text with active segment highlighted */}
      <div style={{
        padding: "20px 22px",
        fontFamily: "var(--f-serif)",
        fontSize: 17,
        lineHeight: 1.75,
        color: "var(--ink-900)",
        borderBottom: "0.5px solid var(--paper-edge)",
        minHeight: 180,
      }}>
        <ActiveText pos={pos} />
      </div>

      {/* Pack timeline visualization */}
      <div style={{
        padding: "18px 22px 14px",
        background: "var(--paper-2)",
      }}>
        <PackTimeline cfg={cfg} pos={pos} />

        <div style={{
          display: "flex", alignItems: "center", gap: 14, marginTop: 18,
        }}>
          <button className="btn btn-icon" style={{ width: 42, height: 42, borderRadius: "50%" }}
            onClick={() => setPlaying(!playing)}>
            <Icon name={playing ? "pause" : "play"} size={16} />
          </button>
          <div style={{
            flex: 1, fontFamily: "var(--f-mono)", fontSize: 11,
            color: "var(--ink-500)",
            display: "flex", justifyContent: "space-between",
          }}>
            <span>{fmtTime(pos * 180)}</span>
            <span>—</span>
            <span>{fmtTime(180)}</span>
          </div>
          <div style={{ display: "flex", gap: 4 }}>
            {[1, 1.25, 1.5, 2].map(s => (
              <button key={s} className="btn" style={{
                height: 26, padding: "0 8px", fontSize: 11,
                fontFamily: "var(--f-mono)",
              }}>×{s}</button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const fmtTime = (s) => {
  const m = Math.floor(s / 60);
  const r = Math.floor(s % 60);
  return `${String(m).padStart(2,"0")}:${String(r).padStart(2,"0")}`;
};

const EXCERPT = [
  "The Sagrada Família, a basilica in Barcelona, is the most famous work of architect Antoni Gaudí.",
  "But it was not finished in his lifetime.",
  "When Gaudí died in 1926, he had worked on the building for more than 40 years.",
];

const ActiveText = ({ pos }) => {
  const n = EXCERPT.length;
  const active = Math.min(n - 1, Math.floor(pos * n));
  return (
    <div>
      {EXCERPT.map((s, i) => (
        <div key={i} style={{
          opacity: i === active ? 1 : 0.35,
          background: i === active ? "var(--marker-yellow)" : "transparent",
          borderBottom: i === active ? "1.5px solid var(--marker-yellow-line)" : "none",
          display: "inline",
          paddingLeft: i === active ? 2 : 0,
          paddingRight: i === active ? 2 : 0,
          transition: "all 0.3s",
          marginRight: 4,
        }}>
          {s}{" "}
        </div>
      ))}
    </div>
  );
};

const PackTimeline = ({ cfg, pos }) => {
  // generate a visual pattern
  const blocks = [];
  for (let i = 0; i < 5; i++) {
    blocks.push({ type: "a", w: 3 });
    for (let r = 0; r < cfg.repeats; r++) blocks.push({ type: "p", w: cfg.pauseKind === "preset" ? cfg.pausePreset : cfg.pauseRatio * 2 });
    if (cfg.mode === "shadow") blocks.push({ type: "a", w: 3 });
  }
  const totalW = blocks.reduce((a, b) => a + b.w, 0);
  return (
    <div style={{
      position: "relative", height: 48,
      display: "flex", gap: 2, alignItems: "center",
      background: "var(--paper-3)", borderRadius: 6, padding: 4,
    }}>
      {blocks.map((b, i) => (
        <div key={i} style={{
          flex: `${b.w} 0 0`,
          height: b.type === "a" ? 32 : 6,
          background: b.type === "a"
            ? "linear-gradient(180deg, var(--ink-indigo), oklch(from var(--ink-indigo) calc(l - 0.1) c h))"
            : "var(--paper-edge)",
          borderRadius: 3,
        }} />
      ))}
      <div style={{
        position: "absolute",
        left: `calc(${pos * 100}% )`,
        top: 0, bottom: 0,
        width: 2, background: "var(--accent-500)",
        boxShadow: "0 0 8px oklch(from var(--accent-500) l c h / 0.6)",
        pointerEvents: "none",
      }} />
    </div>
  );
};

Object.assign(window, { StepExport });
