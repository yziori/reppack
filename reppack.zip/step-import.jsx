// Step 1 — Import (editorial redesign)
// States: empty · loaded · error-format · error-corrupt

const SAMPLE_RECENT = [
  { name: "BBC 6 Minute English — Ep. 321", meta: "5:52  ·  mp3", time: "昨日", segs: 42 },
  { name: "TED · Brené Brown — Vulnerability", meta: "20:19  ·  m4a", time: "3日前", segs: 138 },
  { name: "NHK ニュース ラジオ 02/11", meta: "12:40  ·  mp3", time: "先週", segs: 86 },
];

const StepImport = ({ t, lang, onNext, dropped, setDropped, sourceLang, setSourceLang }) => {
  const [hover, setHover] = React.useState(false);
  const [err, setErr] = React.useState(null);

  const triggerErr = (kind) => {
    setDropped(null);
    setErr(kind);
  };

  const accept = () => {
    setErr(null);
    setDropped({
      name: "walk_with_gaudi.mp3",
      size: "18.4 MB",
      duration: "24:12",
      sr: "48 kHz · stereo",
    });
  };

  return (
    <CanvasShell
      head={
        <div>
          <div className="eyebrow">step 01 · import</div>
          <h1 className="display-h" style={{ marginTop: 10 }}>
            {t.import_h}
          </h1>
          <div className="lede" style={{ marginTop: 12 }}>{t.import_sub}</div>
        </div>
      }
      right={
        <div style={{
          fontFamily: "var(--f-serif)", fontStyle: "italic",
          color: "var(--ink-500)", fontSize: 13,
          textAlign: "right",
        }}>
          <div style={{ fontSize: 11, color: "var(--ink-300)", letterSpacing: "0.05em" }}>PAGE</div>
          <div style={{ fontFamily: "var(--f-serif)", fontSize: 26, fontWeight: 600, color: "var(--ink-900)" }}>01</div>
          <div style={{ fontSize: 10, color: "var(--ink-300)" }}>— of 05 —</div>
        </div>
      }
      foot={
        <NavFoot
          t={t}
          onBack={() => {}}
          backDisabled
          nextDisabled={!dropped}
          onNext={onNext}
          kbdHint={dropped ? "Enter で次へ" : "ファイルを選択"}
        />
      }
    >
      <div style={{ display: "grid", gridTemplateColumns: "1.35fr 1fr", gap: 36 }} data-screen-label="01 Import">
        <div>
          <div
            onMouseEnter={() => setHover(true)}
            onMouseLeave={() => setHover(false)}
            onClick={() => !err && !dropped && accept()}
            style={{
              border: "1.5px dashed " + (err ? "oklch(from var(--err) l c h / 0.5)" : hover && !dropped ? "var(--accent-500)" : "var(--paper-edge)"),
              background: err ? "oklch(from var(--err) l c h / 0.04)" : hover && !dropped ? "oklch(from var(--accent-500) l c h / 0.04)" : "var(--paper-0)",
              borderRadius: 18,
              padding: dropped ? 18 : "46px 28px",
              textAlign: dropped ? "left" : "center",
              cursor: !dropped && !err ? "pointer" : "default",
              transition: "all 0.18s",
              minHeight: 260,
            }}>
            {err ? <ErrorBlock kind={err} onRetry={() => setErr(null)} /> :
             !dropped ? <EmptyDrop t={t} hover={hover} /> :
             <LoadedFile t={t} dropped={dropped} onRemove={() => setDropped(null)} />}
          </div>

          {/* Demo: trigger states */}
          {!dropped && !err && (
            <div style={{
              marginTop: 14, display: "flex", gap: 8, alignItems: "center",
              fontSize: 11, fontFamily: "var(--f-mono)",
              color: "var(--ink-300)",
            }}>
              <span>demo:</span>
              <button className="btn btn-ghost tt" data-tip="対応外の形式" style={{ height: 24, padding: "0 8px", fontSize: 11 }}
                onClick={() => triggerErr("format")}>format error</button>
              <button className="btn btn-ghost tt" data-tip="破損ファイル" style={{ height: 24, padding: "0 8px", fontSize: 11 }}
                onClick={() => triggerErr("corrupt")}>corrupt</button>
              <button className="btn btn-ghost tt" data-tip="大容量ファイル" style={{ height: 24, padding: "0 8px", fontSize: 11 }}
                onClick={() => setDropped({
                  name: "lecture_series_final.wav",
                  size: "1.82 GB",
                  duration: "1:58:22",
                  sr: "96 kHz · stereo",
                  large: true,
                })}>large file</button>
            </div>
          )}
        </div>

        {/* Magazine-style right column */}
        <aside>
          <div style={{
            fontFamily: "var(--f-serif)", fontStyle: "italic",
            fontSize: 13, color: "var(--ink-500)",
            marginBottom: 8, letterSpacing: "0.02em",
          }}>
            ¶ from your shelf
          </div>
          <div style={{
            fontFamily: "var(--f-serif)", fontSize: 22, fontWeight: 600,
            color: "var(--ink-900)", letterSpacing: "-0.01em",
            marginBottom: 16,
          }}>{t.import_recent}</div>

          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            {SAMPLE_RECENT.map((r, i) => (
              <button key={i} className="slide-in" style={{
                padding: "14px 12px",
                display: "grid",
                gridTemplateColumns: "32px 1fr auto",
                gap: 12, alignItems: "center",
                background: "transparent",
                border: "none",
                borderTop: i === 0 ? "0.5px solid var(--paper-edge)" : "none",
                borderBottom: "0.5px solid var(--paper-edge)",
                textAlign: "left",
                cursor: "pointer",
                fontFamily: "inherit",
                animationDelay: `${i * 50}ms`,
              }}
              onMouseEnter={e => e.currentTarget.style.background = "oklch(from var(--accent-500) l c h / 0.04)"}
              onMouseLeave={e => e.currentTarget.style.background = "transparent"}>
                <div style={{
                  fontFamily: "var(--f-serif)", fontSize: 18, fontStyle: "italic",
                  color: "var(--accent-500)", fontWeight: 600,
                }}>{String(i + 1).padStart(2, "0")}</div>
                <div style={{ minWidth: 0 }}>
                  <div style={{
                    fontSize: 13, fontWeight: 500, color: "var(--ink-900)",
                    overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
                    fontFamily: "var(--f-sans)",
                  }}>{r.name}</div>
                  <div style={{
                    fontSize: 11, color: "var(--ink-500)", marginTop: 2,
                    fontFamily: "var(--f-mono)",
                  }}>{r.meta}  ·  {r.segs} seg</div>
                </div>
                <div style={{
                  fontSize: 10.5, color: "var(--ink-300)",
                  fontFamily: "var(--f-serif)", fontStyle: "italic",
                }}>{r.time}</div>
              </button>
            ))}
          </div>

          <div style={{ marginTop: 26 }} className="rule-ornament">❋</div>

          <div className="marginalia" style={{ marginTop: 18 }}>
            <b>対応形式</b>
            MP3 · M4A · WAV · FLAC · OGG · Opus<br/>
            <span style={{ color: "var(--ink-300)" }}>最大 2 時間 · 48 kHz まで</span>
          </div>
        </aside>
      </div>
    </CanvasShell>
  );
};

const EmptyDrop = ({ t, hover }) => (
  <>
    <div style={{
      margin: "0 auto 20px",
      width: 72, height: 72, borderRadius: "50%",
      background: "oklch(from var(--accent-500) l c h / 0.08)",
      display: "grid", placeItems: "center",
      color: "var(--accent-500)",
      border: "1px dashed oklch(from var(--accent-500) l c h / 0.35)",
      transition: "transform 0.25s",
      transform: hover ? "scale(1.05) rotate(-3deg)" : "none",
    }}
    className={hover ? "pulse-ring" : ""}>
      <Icon name="upload" size={26} stroke={1.5} />
    </div>
    <div style={{
      fontFamily: "var(--f-serif)", fontSize: 26, fontWeight: 600,
      color: "var(--ink-900)", letterSpacing: "-0.01em",
      marginBottom: 4,
    }}>
      {t.import_drop}
    </div>
    <div style={{
      fontFamily: "var(--f-serif)", fontStyle: "italic",
      fontSize: 13, color: "var(--ink-500)", marginBottom: 18,
    }}>
      音声ファイルをここにドロップ
    </div>
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 12,
      color: "var(--ink-500)", fontSize: 12, marginBottom: 14,
      fontFamily: "var(--f-serif)", fontStyle: "italic",
    }}>
      <span style={{ height: 1, width: 36, background: "var(--paper-edge)" }}/>
      {t.import_or}
      <span style={{ height: 1, width: 36, background: "var(--paper-edge)" }}/>
    </div>
    <div>
      <button className="btn btn-primary" style={{ margin: "0 auto" }}>
        <Icon name="folder" size={14} /> {t.import_pick}
      </button>
    </div>
    <div style={{
      fontFamily: "var(--f-mono)", fontSize: 10.5,
      color: "var(--ink-300)", marginTop: 24,
      letterSpacing: "0.04em",
    }}>
      MP3 · M4A · WAV · FLAC · OGG   ·   up to 2 h
    </div>
  </>
);

const LoadedFile = ({ t, dropped, onRemove }) => (
  <div className="step-enter">
    <div style={{
      display: "flex", alignItems: "center", gap: 14,
      padding: "14px 16px", background: "var(--paper-2)",
      borderRadius: 12, marginBottom: 14,
      border: "0.5px solid var(--paper-edge)",
    }}>
      <div style={{
        width: 52, height: 52, borderRadius: 10,
        background: "var(--ink-indigo-wash)",
        color: "var(--ink-indigo)",
        display: "grid", placeItems: "center",
        border: "0.5px solid oklch(from var(--ink-indigo) l c h / 0.25)",
        flexShrink: 0,
      }}>
        <Icon name="audio" size={22} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontWeight: 600, fontSize: 14, color: "var(--ink-900)",
          fontFamily: "var(--f-mono)",
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
        }}>{dropped.name}</div>
        <div style={{ fontSize: 12, color: "var(--ink-500)", marginTop: 2, fontFamily: "var(--f-mono)" }}>
          {dropped.duration}  ·  {dropped.size}  ·  {dropped.sr}
        </div>
      </div>
      <div className="chip accent">
        <Icon name="check" size={12} stroke={2.5} />
        {t.import_loaded}
      </div>
      <button className="btn btn-icon btn-ghost tt" data-tip="取り消し" style={{ width: 28, height: 28 }} onClick={onRemove}>
        <Icon name="x" size={13} />
      </button>
    </div>
    <MiniWave />
    {dropped.large && (
      <div className="alert alert-warn" style={{ marginTop: 14 }}>
        <div className="alert-ico"><Icon name="alert" size={18} /></div>
        <div>
          <div style={{ fontWeight: 600, marginBottom: 2 }}>大きなファイルです（1.82 GB）</div>
          <div style={{ color: "var(--ink-700)", fontSize: 12 }}>
            解析には 8〜12 分ほどかかる見込みです。バックグラウンド処理も可能です。
          </div>
        </div>
      </div>
    )}
  </div>
);

const ErrorBlock = ({ kind, onRetry }) => {
  const contents = {
    format: {
      title: "この形式はまだ対応していません",
      body: "音声を含まない動画、または独自形式のように見えます。MP3・M4A・WAV・FLAC・OGG に変換してください。",
      file: "interview_draft.mov",
      hint: "→ HandBrake などで MP3 に書き出すと確実です",
    },
    corrupt: {
      title: "ファイルが読み取れません",
      body: "ヘッダーが壊れているか、転送中に破損した可能性があります。元のファイルを再度エクスポートして試してください。",
      file: "news_clip_broken.mp3",
      hint: "→ 別のファイルで試すか、再エクスポート",
    },
  }[kind];
  return (
    <div style={{ textAlign: "left" }} className="step-enter">
      <div style={{
        margin: "0 auto 16px", width: 56, height: 56, borderRadius: "50%",
        background: "oklch(from var(--err) l c h / 0.12)",
        color: "var(--err)",
        display: "grid", placeItems: "center",
        textAlign: "center",
      }}>
        <Icon name="alert" size={26} />
      </div>
      <div style={{
        textAlign: "center",
        fontFamily: "var(--f-serif)", fontSize: 22, fontWeight: 600,
        color: "var(--ink-900)", marginBottom: 6,
      }}>{contents.title}</div>
      <div style={{
        textAlign: "center",
        fontFamily: "var(--f-serif)", fontStyle: "italic",
        fontSize: 13, color: "var(--ink-500)",
        maxWidth: 380, margin: "0 auto 18px", lineHeight: 1.55,
      }}>{contents.body}</div>

      <div style={{
        padding: "10px 14px", background: "var(--paper-2)",
        borderRadius: 10, margin: "0 auto",
        maxWidth: 360,
        display: "flex", alignItems: "center", gap: 10,
        border: "0.5px solid var(--paper-edge)",
      }}>
        <Icon name="doc" size={14} style={{ color: "var(--ink-500)" }} />
        <span style={{ flex: 1, fontFamily: "var(--f-mono)", fontSize: 12, color: "var(--ink-700)" }}>{contents.file}</span>
        <span className="chip" style={{
          background: "oklch(from var(--err) l c h / 0.1)",
          color: "var(--err)",
          borderColor: "oklch(from var(--err) l c h / 0.3)",
        }}>unreadable</span>
      </div>
      <div style={{
        marginTop: 14, textAlign: "center",
        fontFamily: "var(--f-mono)", fontSize: 11, color: "var(--ink-500)",
      }}>{contents.hint}</div>

      <div style={{ marginTop: 20, display: "flex", gap: 8, justifyContent: "center" }}>
        <button className="btn" onClick={onRetry}>
          <Icon name="back" size={13} /> 戻る
        </button>
        <button className="btn btn-primary" onClick={onRetry}>
          <Icon name="folder" size={13} /> 別のファイルを選ぶ
        </button>
      </div>
    </div>
  );
};

const MiniWave = () => {
  const bars = React.useMemo(() => {
    let x = 42;
    return Array.from({ length: 100 }, (_, i) => {
      x = (x * 9301 + 49297) % 233280;
      const r = x / 233280;
      const env = 0.3 + 0.7 * Math.sin((i / 100) * Math.PI);
      return 0.15 + r * env;
    });
  }, []);
  return (
    <div style={{
      height: 84, padding: "14px 12px 10px",
      background: "var(--paper-0)",
      borderRadius: 10, border: "0.5px solid var(--paper-edge)",
      display: "flex", alignItems: "center", gap: 2,
      position: "relative",
    }}>
      {bars.map((h, i) => (
        <div key={i} style={{
          flex: 1,
          height: `${h * 100}%`,
          background: i < 32 ? "var(--accent-500)" : "var(--ink-700)",
          opacity: i < 32 ? 0.85 : 0.45,
          borderRadius: 1,
          transition: "height 0.3s",
          transitionDelay: `${i * 4}ms`,
        }} />
      ))}
      <div style={{
        position: "absolute", left: "33%", top: 4, bottom: 4,
        width: 1, background: "var(--accent-500)",
      }} />
      <div style={{
        position: "absolute", left: 10, top: 4,
        fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--ink-500)",
      }}>0:00</div>
      <div style={{
        position: "absolute", right: 10, top: 4,
        fontFamily: "var(--f-mono)", fontSize: 9, color: "var(--ink-500)",
      }}>24:12</div>
    </div>
  );
};

Object.assign(window, { StepImport, MiniWave });
