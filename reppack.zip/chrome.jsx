// Window chrome + step sidebar + canvas scaffold — editorial redesign

const MacWindowChrome = ({ title, children }) => (
  <div className="mac-window">
    <div className="mac-titlebar">
      <div className="mac-lights">
        <span className="mac-light red" />
        <span className="mac-light yellow" />
        <span className="mac-light green" />
      </div>
      <div className="mac-title">{title}</div>
      <div style={{ width: 54 }} />
    </div>
    <div className="mac-body">{children}</div>
  </div>
);

const WizardSidebar = ({ t, stepIndex, onStep, stepKeys }) => (
  <aside className="wizard-sidebar" data-screen-label="Sidebar" style={{
    background: "var(--paper-2)",
    backgroundImage: "linear-gradient(180deg, transparent 0, transparent 31px, oklch(from var(--ink-900) l c h / 0.025) 31px, oklch(from var(--ink-900) l c h / 0.025) 32px)",
    backgroundSize: "100% 32px",
  }}>
    <div className="brand">
      <div className="brand-mark">R</div>
      <div>
        <div className="brand-name">{t.appTitle}</div>
        <div className="brand-tag">{t.appTag}</div>
      </div>
    </div>

    <div style={{
      fontFamily: "var(--f-serif)", fontStyle: "italic",
      fontSize: 11, color: "var(--ink-500)",
      letterSpacing: "0.04em",
      padding: "2px 4px 0",
    }}>
      the workflow
    </div>

    <nav className="steps">
      {stepKeys.map((key, i) => {
        const [label, sub] = t.steps[key];
        const cls = [
          "step",
          i === stepIndex ? "is-current" : "",
          i < stepIndex ? "is-done" : "",
        ].join(" ");
        return (
          <div key={key} className={cls} onClick={() => onStep(i)}>
            <div className="step-num">
              {i < stepIndex
                ? <Icon name="check" size={14} stroke={2} />
                : String(i + 1).padStart(2, "0")}
            </div>
            <div className="step-body">
              <div className="step-title">{label}</div>
              <div className="step-sub">{sub}</div>
            </div>
            {i === stepIndex && <span style={{
              alignSelf: "center",
              color: "var(--accent-500)",
              marginRight: 4,
            }}><Icon name="chev-right" size={12} stroke={2.5} /></span>}
          </div>
        );
      })}
    </nav>

    <div style={{ flex: 1 }} />

    <div style={{
      padding: "12px 12px",
      borderRadius: 10,
      background: "var(--paper-0)",
      border: "0.5px solid var(--paper-edge)",
      position: "relative",
    }}>
      <div style={{
        fontFamily: "var(--f-mono)", fontSize: 9.5, fontWeight: 700,
        letterSpacing: "0.14em", color: "var(--accent-500)",
        textTransform: "uppercase", marginBottom: 8,
      }}>☕ tip</div>
      <div style={{
        fontSize: 11.5, color: "var(--ink-700)", lineHeight: 1.55,
        fontFamily: "var(--f-serif)",
      }}>
        {t.import_note}
      </div>
    </div>

    <div style={{
      fontFamily: "var(--f-serif)", fontStyle: "italic",
      fontSize: 10, color: "var(--ink-300)",
      textAlign: "center", letterSpacing: "0.04em",
    }}>
      vol.1 · issue 03 · 2026
    </div>
  </aside>
);

const CanvasShell = ({ head, right, children, foot }) => (
  <section className="wizard-canvas">
    <header className="canvas-head">
      <div>{head}</div>
      <div style={{ display: "flex", gap: 10, alignItems: "center" }}>{right}</div>
    </header>
    <div className="canvas-body">{children}</div>
    {foot && <footer className="canvas-foot">{foot}</footer>}
  </section>
);

const NavFoot = ({ t, onBack, onNext, nextLabel, nextIcon = "next", backDisabled, nextDisabled, extraLeft, extraRight, kbdHint }) => (
  <>
    {extraLeft}
    <button className="btn btn-ghost" onClick={onBack} disabled={backDisabled}>
      <Icon name="back" size={14} /> {t.back}
    </button>
    {kbdHint && (
      <div style={{
        fontFamily: "var(--f-mono)", fontSize: 10.5,
        color: "var(--ink-300)",
        display: "flex", gap: 6, alignItems: "center",
      }}>
        <span className="kbd">↩</span>
        <span>{kbdHint}</span>
      </div>
    )}
    <div style={{ flex: 1 }} />
    {extraRight}
    <button className="btn btn-primary" onClick={onNext} disabled={nextDisabled}>
      {nextLabel || t.next}
      {nextIcon && <Icon name={nextIcon} size={14} stroke={2} />}
    </button>
  </>
);

Object.assign(window, { MacWindowChrome, WizardSidebar, CanvasShell, NavFoot });
