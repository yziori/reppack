// Minimal line-icon set — consistent 20px/1.5-stroke

const Icon = ({ name, size = 18, stroke = 1.5, style = {} }) => {
  const p = {
    width: size, height: size, viewBox: "0 0 24 24",
    fill: "none", stroke: "currentColor", strokeWidth: stroke,
    strokeLinecap: "round", strokeLinejoin: "round",
    style
  };
  switch (name) {
    case "upload":    return <svg {...p}><path d="M12 16V4M7 9l5-5 5 5M4 20h16"/></svg>;
    case "audio":     return <svg {...p}><path d="M9 18V6l10-2v12"/><circle cx="6" cy="18" r="3"/><circle cx="16" cy="16" r="3"/></svg>;
    case "wave":      return <svg {...p}><path d="M2 12h2M6 8v8M10 4v16M14 8v8M18 10v4M22 12h-2"/></svg>;
    case "cut":       return <svg {...p}><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M20 4L8.12 15.88M14.47 14.48L20 20M8.12 8.12L12 12"/></svg>;
    case "mic":       return <svg {...p}><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/></svg>;
    case "sliders":   return <svg {...p}><path d="M4 6h8M16 6h4M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="14" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/></svg>;
    case "download":  return <svg {...p}><path d="M12 4v12M7 11l5 5 5-5M4 20h16"/></svg>;
    case "play":      return <svg {...p}><path d="M6 4l14 8-14 8V4z" fill="currentColor"/></svg>;
    case "pause":     return <svg {...p}><rect x="6" y="4" width="4" height="16" rx="1" fill="currentColor"/><rect x="14" y="4" width="4" height="16" rx="1" fill="currentColor"/></svg>;
    case "next":      return <svg {...p}><path d="M5 12h14M13 5l7 7-7 7"/></svg>;
    case "back":      return <svg {...p}><path d="M19 12H5M11 5l-7 7 7 7"/></svg>;
    case "check":     return <svg {...p}><path d="M4 12l5 5L20 6"/></svg>;
    case "x":         return <svg {...p}><path d="M6 6l12 12M18 6L6 18"/></svg>;
    case "split":     return <svg {...p}><path d="M12 3v8M12 21v-4M8 11h8l-4 6z"/></svg>;
    case "merge":     return <svg {...p}><path d="M6 3h12M8 7l4 4 4-4M12 11v10"/></svg>;
    case "pencil":    return <svg {...p}><path d="M16 3l5 5-11 11H5v-5L16 3z"/></svg>;
    case "trash":     return <svg {...p}><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>;
    case "folder":    return <svg {...p}><path d="M3 6a2 2 0 012-2h4l2 2h8a2 2 0 012 2v10a2 2 0 01-2 2H5a2 2 0 01-2-2V6z"/></svg>;
    case "doc":       return <svg {...p}><path d="M6 3h9l4 4v14H6V3zM14 3v5h5"/></svg>;
    case "settings":  return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"/></svg>;
    case "translate": return <svg {...p}><path d="M4 5h7M7.5 5v2c0 3-2 6-3.5 7M5 11c1.5 2.5 4 4 6 5M13 19l4-10 4 10M14.5 16h5"/></svg>;
    case "repeat":    return <svg {...p}><path d="M17 2l4 4-4 4M3 11v-1a4 4 0 014-4h14M7 22l-4-4 4-4M21 13v1a4 4 0 01-4 4H3"/></svg>;
    case "pause-gap": return <svg {...p}><path d="M3 12h4M10 12h1M14 12h1M18 12h4"/><circle cx="12" cy="12" r="1"/><circle cx="16" cy="12" r="1"/></svg>;
    case "headphones":return <svg {...p}><path d="M3 14v-2a9 9 0 0118 0v2M3 14v4a2 2 0 002 2h2v-8H5a2 2 0 00-2 2zM21 14v4a2 2 0 01-2 2h-2v-8h2a2 2 0 012 2z"/></svg>;
    case "sparkle":   return <svg {...p}><path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2 2-6zM19 14l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7.7-2z"/></svg>;
    case "sun":       return <svg {...p}><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4 12H2M22 12h-2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>;
    case "moon":      return <svg {...p}><path d="M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z"/></svg>;
    case "layers":    return <svg {...p}><path d="M12 2l10 5-10 5-10-5 10-5zM2 12l10 5 10-5M2 17l10 5 10-5"/></svg>;
    case "chev-down": return <svg {...p}><path d="M6 9l6 6 6-6"/></svg>;
    case "chev-right":return <svg {...p}><path d="M9 6l6 6-6 6"/></svg>;
    case "dot":       return <svg {...p}><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>;
    case "gap":       return <svg {...p}><path d="M3 8v8M21 8v8M7 12h4M13 12h4"/></svg>;
    case "alert":     return <svg {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16v.5"/></svg>;
    case "zap":       return <svg {...p}><path d="M13 2L3 14h7l-1 8 10-12h-7l1-8z"/></svg>;
    case "book":      return <svg {...p}><path d="M4 19V5a2 2 0 012-2h13v16H6a2 2 0 00-2 2zM4 19a2 2 0 012-2h13"/></svg>;
    case "paragraph": return <svg {...p}><path d="M13 4v16M17 4v16M7 4h10M7 4a3 3 0 000 6h6"/></svg>;
    case "quote":     return <svg {...p}><path d="M6 7c-2 0-3 2-3 4s1 4 3 4h1V7H6zm9 0c-2 0-3 2-3 4s1 4 3 4h1V7h-1z"/></svg>;
    case "globe":     return <svg {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/></svg>;
    default:          return <svg {...p}><circle cx="12" cy="12" r="6"/></svg>;
  }
};

window.Icon = Icon;
