// Step 4 — Configure practice (MVP: Repeating + Overlapping only)

const StepConfigure = ({ t, onNext, onBack, cfg, setCfg }) => {
  const update = (k, v) => setCfg({ ...cfg, [k]: v });

  const modes = [
    { id: "repeat", label: t.mode_repeat, desc: t.mode_repeat_desc, pattern: ["A", "P×N"] },
    { id: "overlap", label: t.mode_overlap, desc: t.mode_overlap_desc, pattern: ["A"] },
  ];

  const isOverlap = cfg.mode === "overlap";

  return (
    <CanvasShell
      head={
        <div>
          <div className="eyebrow">step 04 · configure</div>
          <h1 className="display-h" style={{ marginTop: 10 }}>
            {t.config_h}
          </h1>
          <div className="lede" style={{ marginTop: 12, maxWidth: "56ch" }}>
            {t.config_sub}
          </div>
        </div>
      }
      right={
        <div style={{
          fontFamily: "var(--f-serif)", fontStyle: "italic",
          color: "var(--ink-500)", textAlign: "right",
        }}>
          <div style={{ fontSize: 11, color: "var(--ink-300)", letterSpacing: "0.05em" }}>PAGE</div>
          <div style={{ fontFamily: "var(--f-serif)", fontSize: 26, fontWeight: 600, color: "var(--ink-900)" }}>04</div>
          <div style={{ fontSize: 10, color: "var(--ink-300)" }}>— of 05 —</div>
        </div>
      }
      foot={<NavFoot t={t} onBack={onBack} onNext={onNext} />}
    >
      <div data-screen-label="04 Configure" style={{
        display: "grid", gridTemplateColumns: "1.5fr 1fr", gap: 24,
      }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
          {/* Practice mode */}
          <div>
            <div className="field-label" style={{ marginBottom: 10 }}>{t.config_mode}</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 12 }}>
              {modes.map(m => {
                const on = cfg.mode === m.id;
                return (
                  <button key={m.id} onClick={() => update("mode", m.id)} style={{
                    background: on ? "var(--paper-0)" : "transparent",
                    border: "1px solid " + (on ? "var(--accent-500)" : "var(--paper-edge)"),
                    boxShadow: on ? "0 0 0 3px oklch(from var(--accent-500) l c h / 0.1)" : "none",
                    padding: 16, borderRadius: 12, textAlign: "left",
                    cursor: "pointer", transition: "all 0.15s",
                  }}>
                    <div style={{
                      fontFamily: "var(--f-serif)", fontSize: 17,
                      fontWeight: 600, color: "var(--ink-900)",
                      marginBottom: 4,
                    }}>
                      {m.label}
                    </div>
                    <div style={{
                      fontSize: 11.5, color: "var(--ink-500)",
                      fontFamily: "var(--f-mono)",
                      marginBottom: 12, lineHeight: 1.45,
                    }}>
                      {m.desc}
                    </div>
                    <PatternViz pattern={m.pattern} highlighted={on} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Pause length — only meaningful for Repeating */}
          {!isOverlap && (
            <div className="card">
              <div style={{ display: "flex", alignItems: "center", marginBottom: 12 }}>
                <div style={{ flex: 1, fontSize: 14, fontFamily: "var(--f-serif)", fontWeight: 600, color: "var(--ink-900)" }}>
                  {t.config_pause}
                </div>
                <div className="segmented" style={{ fontSize: 11 }}>
                  {["preset","ratio"].map(k => (
                    <button key={k}
                      className={cfg.pauseKind === k ? "on" : ""}
                      onClick={() => update("pauseKind", k)}>
                      {k === "preset" ? t.config_pause_preset : t.config_pause_custom}
                    </button>
                  ))}
                </div>
              </div>

              {cfg.pauseKind === "preset" ? (
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  {[1.0, 1.5, 2.0, 3.0].map(v => {
                    const on = cfg.pausePreset === v;
                    return (
                      <button key={v}
                        onClick={() => update("pausePreset", v)}
                        style={{
                          padding: "10px 16px", borderRadius: 10,
                          border: "1px solid " + (on ? "var(--accent-500)" : "var(--paper-edge)"),
                          background: on ? "var(--accent-500)" : "var(--paper-0)",
                          color: on ? "oklch(0.98 0.01 80)" : "var(--ink-900)",
                          fontFamily: "var(--f-mono)", fontSize: 13, fontWeight: 500,
                          cursor: "pointer",
                        }}>
                        {v.toFixed(1)}s
                      </button>
                    );
                  })}
                </div>
              ) : (
                <>
                  <Slider
                    value={cfg.pauseRatio}
                    min={0.5} max={3} step={0.1}
                    onChange={v => update("pauseRatio", v)}
                    format={v => `×${v.toFixed(1)} セグメント長`}
                  />
                  <div style={{
                    marginTop: 14, fontSize: 12, color: "var(--ink-500)",
                    fontFamily: "var(--f-mono)",
                    display: "flex", justifyContent: "space-between",
                  }}>
                    <span>短い ×0.5</span><span>倍 ×1.0</span><span>長い ×3.0</span>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Speed + Repeats */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            <div className="card">
              <div style={{
                fontSize: 14, fontFamily: "var(--f-serif)",
                fontWeight: 600, marginBottom: 10,
              }}>
                {t.config_speed}
              </div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                {[0.75, 1.0, 1.25, 1.5].map(v => {
                  const on = cfg.speed === v;
                  return (
                    <button key={v}
                      onClick={() => update("speed", v)}
                      style={{
                        flex: 1, minWidth: 38,
                        padding: "8px 6px",
                        border: "1px solid " + (on ? "var(--accent-500)" : "var(--paper-edge)"),
                        background: on ? "var(--accent-500)" : "var(--paper-0)",
                        color: on ? "oklch(0.98 0.01 80)" : "var(--ink-900)",
                        borderRadius: 8, cursor: "pointer",
                        fontFamily: "var(--f-mono)", fontSize: 12,
                      }}>
                      ×{v}
                    </button>
                  );
                })}
              </div>
            </div>

            {!isOverlap && (
              <div className="card">
                <div style={{
                  fontSize: 14, fontFamily: "var(--f-serif)",
                  fontWeight: 600, marginBottom: 10,
                }}>
                  {t.config_repeat}
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <button className="btn btn-icon" onClick={() => update("repeats", Math.max(1, cfg.repeats - 1))}>−</button>
                  <div style={{
                    flex: 1, textAlign: "center",
                    fontFamily: "var(--f-serif)", fontSize: 28, fontWeight: 600,
                  }}>{cfg.repeats}</div>
                  <button className="btn btn-icon" onClick={() => update("repeats", Math.min(10, cfg.repeats + 1))}>+</button>
                </div>
                <div style={{
                  fontSize: 11, fontFamily: "var(--f-mono)",
                  color: "var(--ink-500)", textAlign: "center", marginTop: 4,
                }}>× per segment</div>
              </div>
            )}
          </div>
        </div>

        {/* Summary panel */}
        <SummaryCard t={t} cfg={cfg} />
      </div>
    </CanvasShell>
  );
};

const PatternViz = ({ pattern, highlighted }) => (
  <div style={{
    display: "flex", gap: 3, alignItems: "center", height: 28,
  }}>
    {pattern.map((p, i) => {
      const isPause = p.startsWith("P");
      return (
        <React.Fragment key={i}>
          <div style={{
            flex: isPause ? 1 : 1.8,
            height: isPause ? 3 : 16,
            background: isPause
              ? (highlighted ? "var(--ink-300)" : "var(--paper-edge)")
              : (highlighted ? "var(--accent-500)" : "var(--ink-500)"),
            borderRadius: 2,
            position: "relative",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 9, fontFamily: "var(--f-mono)",
            color: isPause ? "var(--ink-500)" : "oklch(0.98 0.01 80)",
            fontWeight: 600, letterSpacing: "0.04em",
          }}>
            {!isPause && p}
            {p === "P×N" && <span style={{
              position: "absolute", top: -14,
              fontSize: 9, color: "var(--ink-500)",
            }}>×N</span>}
          </div>
        </React.Fragment>
      );
    })}
  </div>
);

const Slider = ({ value, min, max, step, onChange, format }) => {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div>
      <div style={{
        fontFamily: "var(--f-mono)", fontSize: 13,
        marginBottom: 10, textAlign: "center",
        color: "var(--accent-500)", fontWeight: 600,
      }}>
        {format(value)}
      </div>
      <div style={{ position: "relative", height: 28 }}>
        <div style={{
          position: "absolute", left: 0, right: 0, top: 13,
          height: 2, background: "var(--paper-3)", borderRadius: 1,
        }} />
        <div style={{
          position: "absolute", left: 0, top: 13,
          height: 2, width: `${pct}%`,
          background: "var(--accent-500)", borderRadius: 1,
        }} />
        <div style={{
          position: "absolute", left: `calc(${pct}% - 9px)`, top: 6,
          width: 18, height: 18, borderRadius: "50%",
          background: "var(--accent-500)",
          boxShadow: "0 2px 6px oklch(from var(--accent-500) l c h / 0.4), 0 0 0 3px oklch(0.98 0.01 80)",
        }} />
        <input type="range" min={min} max={max} step={step} value={value}
          onChange={e => onChange(parseFloat(e.target.value))}
          style={{
            position: "absolute", inset: 0, width: "100%", height: "100%",
            opacity: 0, cursor: "pointer",
          }}/>
      </div>
    </div>
  );
};

const SummaryCard = ({ t, cfg }) => {
  const segCount = 8;
  const audioTotal = 37.5;
  const isOverlap = cfg.mode === "overlap";
  const pauseLen = isOverlap ? 0 : (cfg.pauseKind === "preset" ? cfg.pausePreset : cfg.pauseRatio * (audioTotal / segCount));
  const repeats = isOverlap ? 1 : cfg.repeats;
  const perSeg = (audioTotal / segCount) + pauseLen * repeats;
  const totalSec = perSeg * segCount / cfg.speed;
  const mins = Math.floor(totalSec / 60);
  const secs = Math.round(totalSec % 60);
  const mb = (totalSec * 0.016).toFixed(1);

  return (
    <div style={{
      padding: 22,
      background: "var(--paper-2)",
      border: "0.5px solid var(--paper-edge)",
      borderRadius: 16,
      position: "relative",
      overflow: "hidden",
    }}>
      <div style={{
        position: "absolute", top: -4, right: 20,
        width: 28, height: 60,
        background: "var(--accent-500)",
        clipPath: "polygon(0 0, 100% 0, 100% 100%, 50% 80%, 0 100%)",
        boxShadow: "0 2px 4px oklch(from var(--accent-500) l c h / 0.4)",
      }}/>

      <div style={{
        fontFamily: "var(--f-serif)", fontSize: 18, fontWeight: 600,
        marginBottom: 18, color: "var(--ink-900)",
      }}>
        {t.config_summary}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <SumRow label={t.summary_dur} value={`${mins}:${String(secs).padStart(2, "0")}`} big />
        <SumRow label={t.summary_segs} value={`${segCount}`} />
        <SumRow label={t.summary_size} value={`~ ${mb} MB`} />

        <div style={{
          marginTop: 8, paddingTop: 14,
          borderTop: "0.5px dashed var(--paper-edge)",
        }}>
          <div className="field-label" style={{ marginBottom: 10 }}>パターン</div>
          <FullPatternViz cfg={cfg} />
        </div>
      </div>
    </div>
  );
};

const SumRow = ({ label, value, big }) => (
  <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between" }}>
    <span style={{ fontSize: 12, color: "var(--ink-500)" }}>{label}</span>
    <span style={{
      fontFamily: big ? "var(--f-serif)" : "var(--f-mono)",
      fontSize: big ? 28 : 14,
      fontWeight: big ? 600 : 500,
      color: "var(--ink-900)",
      letterSpacing: big ? "-0.01em" : 0,
    }}>{value}</span>
  </div>
);

const FullPatternViz = ({ cfg }) => {
  const isOverlap = cfg.mode === "overlap";
  const blocks = [];
  for (let i = 0; i < 2; i++) {
    blocks.push({ type: "a", label: `#${i+1}` });
    if (!isOverlap) {
      for (let r = 0; r < cfg.repeats; r++) blocks.push({ type: "p" });
    }
  }
  return (
    <div style={{ display: "flex", gap: 3, height: 28, alignItems: "center" }}>
      {blocks.map((b, i) => (
        <div key={i} style={{
          flex: b.type === "a" ? 2 : 1,
          height: b.type === "a" ? 18 : 3,
          background: b.type === "a" ? "var(--ink-indigo)" : "var(--ink-300)",
          borderRadius: 2,
          color: "oklch(0.98 0.01 80)",
          fontSize: 9, fontFamily: "var(--f-mono)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}>
          {b.label}
        </div>
      ))}
      <span style={{
        marginLeft: 4, fontSize: 10, color: "var(--ink-300)",
        fontFamily: "var(--f-mono)",
      }}>…</span>
    </div>
  );
};

Object.assign(window, { StepConfigure });
